from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch


class Arm():
    arm_motor = Motor(Port.F, Direction.COUNTERCLOCKWISE)
    arm_motor.reset_angle()
    threeTime = StopWatch()
    def resetAngle(self):
    
        self.arm_motor.reset_angle()
    def setClosed(self):
        self.arm_motor.run_target(650,650)
        print(self.arm_motor.angle())

    def setOpen(self):
        self.arm_motor.run_target(650,0)  
        print(self.arm_motor.angle())

    def setSpecificTarget(self,target):
        self.arm_motor.run_target(2000,target)

    def isHighThree(self):
        self.threeTime.reset()
        while(self.threeTime.time() > 500):
            self.arm_motor.run_target(300)
            if (self.arm_motor.angle() > 500):
                break
        