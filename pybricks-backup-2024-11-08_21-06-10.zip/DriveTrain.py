from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

class DriveTrain():
        left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
        right_motor = Motor(Port.B, Direction.CLOCKWISE)
        left_motor.reset_angle()
        right_motor.reset_angle()
        drive_base = DriveBase(left_motor,right_motor,87,130.5)
        drive_base.use_gyro(True)
        drive_base.reset()

        def andar(self,dist):
            self.drive_base.settings(500,500,600,400) #angulo dos motores(esquerdo, direito) rotacao dos motores(esquerdo, direito) 
            self.drive_base.straight(dist * 10)
            

        def curva(self,radius,angle):
            self.drive_base.settings(500,500,500,500)
            self.drive_base.curve(radius,angle)

        def girar(self,graus): 
            self.drive_base.settings(200,600,400,(200,700))
            self.drive_base.turn(graus)
        def getAngle(self):
            print(self.drive_base.angle())
            
    