    from pybricks.hubs import PrimeHub
    from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
    from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
    from pybricks.robotics import DriveBase
    from pybricks.tools import wait, StopWatch

    hub = PrimeHub()

    class Detector():
        colorPoluent = ColorSensor(Port.E)
        timer = StopWatch()
        timer.reset()
        mainPoluent = ""

        def detectPoluent(self):
            self.timer.reset()
            while (self.timer.time() < 1500):
                if (self.colorThree.color() == (Color.RED or Color.MAGENTA)):
                    self.mainPoluent = "RED"
                    break
                else:
                    self.mainPoluent = "BLACK"
                    break
            return (self.mainPoluent == "RED")